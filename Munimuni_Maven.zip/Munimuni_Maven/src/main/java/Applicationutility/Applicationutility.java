package Applicationutility;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Baselibrary.Baselibrary;

public class Applicationutility extends Baselibrary
{
	
	public static void doubleclick (WebElement Element)
	{
		try 
		{
			Actions act = new Actions(driver);
			act.doubleClick(Element).perform();
		} 
		catch (Exception e) 
		{
			System.out.println("Issue in Double click method" + e);
		}
	}
	public static void rightclick(WebElement Element)
	{
		Actions act = new Actions(driver);
		act.contextClick(Element).perform();
	}
	public static void draganddrop(WebElement src,WebElement dest)
	{
		Actions act = new Actions(driver);
		act.dragAndDrop(src, dest).build().perform();
	}
	public static void clickme(WebElement ele)
	{
		WebDriverWait wait=new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.elementToBeClickable(ele));
		ele.click();
	}
	public static void sendkeys(WebElement ele, String value)
	{
		WebDriverWait wait=new WebDriverWait(driver, 5);
		wait.until(ExpectedConditions.invisibilityOf(ele));
		ele.sendKeys(value);
	}
	public static void changewindow (int tabno) 
	{
	Set<String> set=driver.getWindowHandles();
	ArrayList<String> tabs=new ArrayList<String>(set);
	driver.switchTo().window(tabs.get(tabno));
	}
	public static void fileuploading (String path)
	{
			try 
			{
				StringSelection sel= new StringSelection(path);
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents(sel, null);
			
				Robot robot= new Robot();
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_V);
				robot.keyRelease(KeyEvent.VK_V);
				robot.keyRelease(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyRelease(KeyEvent.VK_ENTER);
			
			} 
			catch (Exception e) 
			{
				System.out.println("Issue in getrobot class "+e);
			}

	}
	public static void dropdownbyvalue(WebElement ele, String value)
	{
		Select sel=new Select (ele);
		sel.selectByVisibleText(value);
	}
	public static void dropdownbyindex(WebElement ele, int index)
	{
		Select sel=new Select (ele);
		sel.selectByIndex(index);
	}
	
	public static void mousehover(WebElement ele)
	{
		Actions act = new Actions (driver);
		act.moveToElement(ele).perform();
	}
	
	public static void mousehoverclick(WebElement ele, String linktext)
	{
		Actions act = new Actions (driver);
		act.moveToElement(ele).build().perform();
		driver.findElement(By.linkText(linktext)).click();
	}
	
	public static void Slider(String element) {
		try {
			WebElement Slider = driver.findElement(By.xpath(element));
			Actions SliderAction = new Actions(driver);
			SliderAction.clickAndHold(Slider).moveByOffset((50), 0).release().perform();
		} catch (Exception e) {
			System.out.println("issue in Slider" + e);
		}
	}
	
	public static void scrollByXPath(WebElement xpath) {
		try {
			JavascriptExecutor je = (JavascriptExecutor) driver;
			je.executeScript("arguments[0].scrollIntoView(true);", xpath);
		} catch (Exception e) {
			System.out.println("Issue in ScrollByxpath" + e);
		}
	}
	
	
	
	
}
