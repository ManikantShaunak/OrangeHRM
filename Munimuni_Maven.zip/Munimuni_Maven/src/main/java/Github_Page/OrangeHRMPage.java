package Github_Page;


import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import Applicationutility.Applicationutility;
import Baselibrary.Baselibrary;
import Propertyutility.Propertyutility;


public class OrangeHRMPage extends Baselibrary
{
	
	public void gettitle()
	
	{
		String title =driver.getTitle();
		System.out.println ("Github Title is :"+ title);
		String Actualdata=driver.getTitle();
		String expecteddata=Propertyutility.getReaddata("Github");
		Assert.assertEquals(expecteddata, Actualdata);
	}
	public OrangeHRMPage() 
	{
		PageFactory.initElements(driver, this);
	}

	
	
	@FindBy(xpath = "//input[@name='username']")
	private WebElement UserName_or_Email;
	
	@FindBy(xpath = "//input[@type='password']")
	private WebElement password;
	
	@FindBy(xpath = "//button[@type='submit']")
	private WebElement Login;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a/span")
	private WebElement Admin;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[1]/span")
	private WebElement UserManagement;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[1]/ul/li/a")
	private WebElement User;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[2]/span")
	private WebElement Job;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[2]/ul/li[1]/a")
	private WebElement JobTitles;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[3]/span")
	private WebElement Orgnaization;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[3]/ul/li[1]/a")
	private WebElement GeneralInformation;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[4]/span")
	private WebElement Qualification;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[4]/ul/li[1]/a")
	private WebElement Skills;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[5]/a")
	private WebElement Nationalties;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[1]/header/div[2]/nav/ul/li[6]/a")
	private WebElement CorporateBranding;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[7]/span")
	private WebElement Configuration;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[2]/nav/ul/li[7]/ul/li[1]/a")
	private WebElement EmailConfiguration;
	
	@FindBy(xpath = "//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[2]/ul/li/span")
	private WebElement LogoutOption;
	
	@FindBy(xpath = "//*[@id='app']/div[1]/div[1]/header/div[1]/div[2]/ul/li/ul/li[4]/a")
	private WebElement Logout;
	
	public void clickonUserName_or_Email() throws AWTException, InterruptedException 
	{
		UserName_or_Email.sendKeys("Admin");
	}	
	
	public void clickonpassword() 
	{
		password.sendKeys("admin123");
	}
	public void clickonLogin() 
	{
		Login.click();
	}
	public void clickonAdmin() 
	{
		Admin.click();
	}
	public void clickonUserManagement() 
	{
		UserManagement.click();
	}
	public void clickonUser() 
	{
		User.click();
	}
	public void clickonJob() 
	{
		Job.click();
	}
	public void clickonJobTitles() 
	{
		JobTitles.click();
	}
	public void clickonOrgnaization() 
	{
		Orgnaization.click();
	}
	public void clickonGeneralInformation() 
	{
		GeneralInformation.click();
	}
	public void clickonQualification() 
	{
		Qualification.click();
	}
	public void clickonSkills() 
	{
		Skills.click();
	}
	public void clickonNationalties() 
	{
		Nationalties.click();
	}
	public void clickonCorporateBranding() 
	{
		CorporateBranding.click();
	}
	public void clickonConfiguration() 
	{
		Configuration.click();
	}
	public void clickonEmailConfiguration() 
	{
		EmailConfiguration.click();
	}
	public void clickonLogoutOption() 
	{
		LogoutOption.click();
	}
	public void clickonLogout() 
	{
		Logout.click();
	}
}