package Github_Page;


import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import Applicationutility.Applicationutility;
import Baselibrary.Baselibrary;
import Propertyutility.Propertyutility;


public class Login_Page extends Baselibrary
{
	
	public void gettitle()
	
	{
		String title =driver.getTitle();
		System.out.println ("Github Title is :"+ title);
		String Actualdata=driver.getTitle();
		String expecteddata=Propertyutility.getReaddata("Github");
		Assert.assertEquals(expecteddata, Actualdata);
	}
	public Login_Page() 
	{
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@href='/login']")
	private WebElement signin;
	
	@FindBy(xpath = "//*[@id='login_field']")
	private WebElement UserName_or_Email;
	
	@FindBy(xpath = "//*[@id='password']")
	private WebElement password;
	
	@FindBy(xpath = "//*[@value='Sign in']")
	private WebElement signsubmit;
	
	@FindBy(xpath = "//*[@id='repos-container']/div/a[1]")
	private WebElement createRepository;
	
	@FindBy(xpath = "//*[@id='repository_name']")
	private WebElement RepositoryName;
	
	@FindBy(xpath = "//*[@id='input-check-2449']")
	private WebElement Repositorytext;
	
	@FindBy(xpath = "//*[@id='new_repository']/div[5]/button")
	private WebElement CreateRepositoryBTN;
	
	@FindBy(xpath = "//*[@id='issues-tab']")
	private WebElement IssueTab;
	
	@FindBy(xpath = "//*[@class='d-none d-md-block']")
	private WebElement NewIssueTab;
	
	@FindBy(xpath = "//*[@name='issue[title]']")
	private WebElement FillIssueDetail;
	
	@FindBy(xpath = "//*[@class='btn-primary btn']")
	private WebElement SubmitIssuBTN;
	
	@FindBy(xpath = "//*[@href='/Muni0786/MuniAhmad123/issues/new/choose']")
	private WebElement IssueNext;
	
	@FindBy(xpath = "//*[@id='new_comment_field']")
	private WebElement AddComment;
	
	
	@FindBy(xpath = "//*[@id='partial-new-comment-form-actions']/div/div[2]/button")
	private WebElement CommentBTN;
	
	@FindBy(xpath = "//*[@href='https://github.com/Muni0786/MuniAhmad123/issues/1']")
	private WebElement IssueDetailno1;
	
	@FindBy(xpath = "//*[@id='settings-tab']")
	private WebElement Setting;
	
	@FindBy(xpath = "//*[@id='options_bucket']/div[8]/ul/li[4]/details/summary")
	private WebElement DeleteRepositoryBTN;
	
	@FindBy(xpath = "(//input[@class='form-control input-block'])[4]")
	private WebElement NameInput;
	
	@FindBy(xpath = "(//*[@class='d-md-inline-block d-none'])[2]")
	private WebElement DeleteRepository;
	
	
	public void clickonsignin() 
	{
		signin.click();
	}
	public void clickonUserName_or_Email() throws AWTException, InterruptedException 
	{
		UserName_or_Email.click();
		UserName_or_Email.sendKeys(Propertyutility.getReaddata("username"));
    	String Actual=UserName_or_Email.getText();
		System.out.println(Actual);
	}	
	
	public void clickonpassword() 
	{
		password.click();
		password.sendKeys(Propertyutility.getReaddata("password"));
	}
	public void clickonsignsubmit() 
	{
		signsubmit.click();
	}
	public void clickoncreateRepository() throws InterruptedException 
	{	Thread.sleep(2000);
		createRepository.click();
	}
	public void clickonRepositoryName() throws InterruptedException 
	{
		RepositoryName.click();
		RepositoryName.sendKeys(Propertyutility.getReaddata("RepositoryName"));
		Thread.sleep(2000);
		CreateRepositoryBTN.click();
	}
	//public void gettooltip()
//	{
//		try {
//			Thread.sleep(3000);
//			String existingName=Repositorytext.getText();
//			String[]text=existingName.split(" ");
//			String Actual_data=text[0];
//			System.out.println(Actual_data);
//		} catch (Exception e) {
//			System.out.println("Issue in gettooltip"+e);
//		}
//		
//		
//	}
//	public void CreateRepositoryBTN() throws InterruptedException 
//	{
//		CreateRepositoryBTN.click();
//	}
	
	public void clickonIssueTab()
	{	
		IssueTab.click();
	}
	public void clickonNewIssueTab()
	{	
		NewIssueTab.click();
	}

	public void clickonFillIssueDetail()
	{	
		FillIssueDetail.click();
		FillIssueDetail.sendKeys(Propertyutility.getReaddata("Issue1"));
		SubmitIssuBTN.click();
	}
	public void clickonFillIssueDetail1()
	{	IssueNext.click();
		FillIssueDetail.click();
		FillIssueDetail.sendKeys(Propertyutility.getReaddata("Issue2"));
		SubmitIssuBTN.click();
	}
	public void clickonAddComment() throws InterruptedException
	{	AddComment.click();
		AddComment.sendKeys(Propertyutility.getReaddata("comment"));
		CommentBTN.click();
		Thread.sleep(2000);
		IssueDetailno1.click();
	}
	public void clickonDeleteRepository()
	{
		try {
			
			Thread.sleep(2000);
			Setting.click();
			Thread.sleep(2000);
			Applicationutility.scrollByXPath(DeleteRepositoryBTN);
			
			DeleteRepositoryBTN.click();
			NameInput.sendKeys(Propertyutility.getReaddata("DelRep"));
			DeleteRepository.click();
			Thread.sleep(2000);
		
			
		} catch (Exception e) {
			
		}
	}
	public void VerifyDelmsg()
	{
		SoftAssert SA=new SoftAssert();
		WebElement DelSussmsg=driver.findElement(By.xpath("//*[@id='js-flash-container']/div/div/text()[2]"));
		String actual=DelSussmsg.getText();
		String Ex=Propertyutility.getReaddata("DelMsg");
		SA.assertEquals(actual, Ex);
		System.out.println(Ex);
		SA.assertAll();
	}
}