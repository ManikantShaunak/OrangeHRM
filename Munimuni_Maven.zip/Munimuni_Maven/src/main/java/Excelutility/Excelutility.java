package Excelutility;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelutility 
{
		static String path="C:\\Users\\ma46377\\eclipse-workspace\\Muni_muni\\Test_Data\\Test_01.xlsx";
		public static String getReaddata(int rowno,int colno)
		{
			String value="";
			
		try {
			FileInputStream fis=new FileInputStream(path);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sheet=wb.getSheetAt(1);
			value=sheet.getRow(rowno).getCell(colno).getStringCellValue();
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
		return value;
		}
	public static void main(String[] args)
	{
		for(int i=0;i<=5;i++)
		{
		String out=getReaddata(i,1);
		String out1=getReaddata(i,0);
		System.out.println(out+" "+out1);
		}}
}