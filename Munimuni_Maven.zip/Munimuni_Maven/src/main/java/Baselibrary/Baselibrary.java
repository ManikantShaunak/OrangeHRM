package Baselibrary;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

import Screenshortutility.Screenshortutility;

public class Baselibrary 
{
	public static WebDriver driver;
	public void getlaunch (String url)
	{
		System.setProperty("webdriver.chrome.driver" , "D:\\Java_Programe\\Java_Programe\\Java_Programe\\Munimuni_Maven\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.findElement(By.xpath("//*[text()='×']")).click();
		//driver.findElement(By.xpath("//*[text()='Practice']")).click();
	}
	
	@AfterMethod
	public void getanalysis(ITestResult result)
	{
		String name = result.getMethod().getMethodName();
		if(result.isSuccess())
		{
			Screenshortutility.getscreenshot("passed", name);

		}
		else if(result.getStatus()==ITestResult.FAILURE)
		{
			Screenshortutility.getscreenshot("failed", name);

		}
	}
@AfterTest
public void teardown()
{
	//driver.quit();
}
}