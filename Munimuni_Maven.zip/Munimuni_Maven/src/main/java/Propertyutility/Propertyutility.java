package Propertyutility;

import java.io.FileInputStream;
import java.util.Properties;

public class Propertyutility 
{
		static String path="D:\\Java_Programe\\Java_Programe\\Java_Programe\\Munimuni_Maven\\Test_Data\\config.properties";
		public static String getReaddata(String key)
		{
		String value="";
		try 
		{
			FileInputStream fis= new FileInputStream(path);
			Properties prop= new Properties();
			prop.load(fis);
			value=prop.getProperty(key);
		} 
		catch (Exception e)
		{
			System.out.println("Issue in getvalue "+e);
		}
		return value;
	}
	
	}
