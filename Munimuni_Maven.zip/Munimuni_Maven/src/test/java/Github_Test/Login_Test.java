package Github_Test;

import java.awt.AWTException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Baselibrary.Baselibrary;
import Github_Page.Login_Page;

public class Login_Test extends Baselibrary
{
	Login_Page ob;
	
	@BeforeTest
	public void getGithubUrl()
	{
		getlaunch("http://Github.com");
		ob = new Login_Page();
	}
	@Test(priority = 0)
	public void gettitle()
	{
	ob.gettitle();
	}
	@Test(priority = 1)
	public void clickonsignin()
	{
		ob.clickonsignin();
	}
	@Test(priority = 2)
	public void clickonUserName_or_Email() throws AWTException, InterruptedException
	{
		ob.clickonUserName_or_Email();
	}
	@Test(priority = 3)
	public void clickonpassword()
	{
		ob.clickonpassword();
	}
	@Test(priority = 4)
	public void clickonsignsubmit()
	{
		ob.clickonsignsubmit();
	}
	@Test(priority = 5)
	public void clickoncreateRepository() throws InterruptedException
	{
		ob.clickoncreateRepository();
	}
	@Test(priority = 6)
	public void clickonRepositoryName() throws InterruptedException
	{
		ob.clickonRepositoryName();
	}
//	@Test(priority = 7)
//	public void gettooltip()
//	{
//		//ob.gettooltip();
////	}
//	@Test(priority = 8)
//	public void CreateRepositoryBTN() throws InterruptedException
//	{
//		ob.CreateRepositoryBTN();
//	}
	@Test(priority = 9)
	public void clickonIssueTab() throws InterruptedException
	{
		ob.clickonIssueTab();
	}
	@Test(priority = 10)
	public void clickonNewIssueTab() throws InterruptedException
	{
		ob.clickonNewIssueTab();
	}
	@Test(priority = 11)
	public void clickonFillIssueDetail()
	{
		ob.clickonFillIssueDetail();
	}
	@Test(priority = 12)
	public void clickonFillIssueDetail1()
	{
		ob.clickonFillIssueDetail1();
	}
	@Test(priority = 13)
	public void clickonAddComment() throws InterruptedException
	{
		ob.clickonAddComment();
	}
	@Test(priority = 14)
	public void clickonDeleteRepository()
	{
		ob.clickonDeleteRepository();
	}
	@Test(priority = 15)
	public void VerifyDelmsg()
	{
		ob.VerifyDelmsg();
	}
	}