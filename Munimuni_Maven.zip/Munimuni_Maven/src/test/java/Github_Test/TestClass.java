package Github_Test;

import java.awt.AWTException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Baselibrary.Baselibrary;

import Github_Page.OrangeHRMPage;

public class TestClass extends Baselibrary
{
	OrangeHRMPage ob;
	
	@BeforeTest
	public void getGithubUrl()
	{
		getlaunch("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		ob = new OrangeHRMPage();
	}
	
	
	@Test(priority = 1)
	public void clickonUserName_or_Email() throws AWTException, InterruptedException
	{
		ob.clickonUserName_or_Email();
	}
	
	@Test(priority = 2)
	public void clickonpassword()
	{
		ob.clickonpassword();
	}
	@Test(priority = 3)
	public void clickonLogin()
	{
		ob.clickonLogin();
	}
	@Test(priority = 4)
	public void clickonAdmin()
	{
		ob.clickonAdmin();
	}
	@Test(priority = 5)
	public void clickonUserManagement()
	{
		ob.clickonUserManagement();
	}
	@Test(priority = 6)
	public void clickonUser()
	{
		ob.clickonUser();
	}
	@Test(priority = 7)
	public void clickonJob()
	{
		ob.clickonJob();
	}
	@Test(priority = 8)
	public void clickonJobTitles()
	{
		ob.clickonJobTitles();
	}
	
	
	@Test(priority = 9)
	public void clickonOrgnaization()
	{
		ob.clickonOrgnaization();
	}
	@Test(priority = 10)
	public void clickonGeneralInformation()
	{
		ob.clickonGeneralInformation();
	}
	@Test(priority = 11)
	public void clickonQualification()
	{
		ob.clickonQualification();
	}
	@Test(priority = 12)
	public void clickonSkills()
	{
		ob.clickonSkills();
	}
	@Test(priority = 13)
	public void clickonNationalties()
	{
		ob.clickonNationalties();
	}
	@Test(priority = 14)
	public void clickonCorporateBranding()
	{
		ob.clickonCorporateBranding();
	}
	@Test(priority = 15)
	public void clickonConfiguration()
	{
		ob.clickonConfiguration();
	}
	@Test(priority = 16)
	public void clickonEmailConfiguration()
	{
		ob.clickonEmailConfiguration();
	}
	@Test(priority = 17)
	public void clickonLogoutOption()
	{
		ob.clickonLogoutOption();
	}
	@Test(priority = 18)
	public void clickonLogout()
	{
		ob.clickonLogout();
	}
	}